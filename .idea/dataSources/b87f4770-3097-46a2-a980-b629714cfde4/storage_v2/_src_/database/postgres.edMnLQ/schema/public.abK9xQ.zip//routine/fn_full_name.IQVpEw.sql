create function fn_full_name(first_name character varying, last_name character varying) returns character varying
    language plpgsql
as
$$
    DECLARE full_name VARCHAR(100);
    BEGIN
        SELECT CONCAT_WS(' ', INITCAP(first_name), INITCAP(last_name)) INTO full_name;
        RETURN full_name;
    END;
$$;

alter function fn_full_name(varchar, varchar) owner to postgres;

